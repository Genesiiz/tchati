export function encodeHTML(string) {
  return string.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
}

// export default function (val) {
//   val = removeHtml(val, '<!--', '-->')
//   val = removeHtml(val, '<script', '/script>')
//   val = removeHtml(val, '<style', '/style>')
//   val = val.replace(/<[^>]*>/igm, '')
//   return val
// }

// const removeHtml = (val, open, close) => {
//   var n
//   var nn
//   var html = val

//   do {
//     n = html.indexOf(open)
//     if (n >= 0) {
//       nn = html.indexOf(close, n + open.length)
//       if (nn > 0) {
//         html = html.substr(0, n - 1) + html.substr(nn + close.length)
//         html = html.substr(0, n - 1) + html.substr(nn + close.length)
//       }
//     }
//   }
//   while ((n >= 0) && (nn > 0))
//   return html
// }
