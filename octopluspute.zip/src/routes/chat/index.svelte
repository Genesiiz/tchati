<script>
  import Login from './components/login.svelte';
  import Chat from './components/chat.svelte';
  import { usernameStore, loggedStore } from '@/routes/chat/store.js';
</script>

<svelte:head>
	<title>Chat</title>
</svelte:head>

<div class="wrapper">
  {#if !$loggedStore}
    <h1>Welcome to the octopluspute</h1>
    <Login />
  {:else}
    <h1>Welcome, {$usernameStore}</h1>
    <Chat />
  {/if}
</div>